package com.example.taskapp

data class Tasks(val id:Int, val tasks: String, val content: String)
